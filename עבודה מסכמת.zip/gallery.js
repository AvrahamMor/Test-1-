document.addEventListener("DOMContentLoaded", function () {
    const addProductBtn = document.getElementById("add-product");
    const gallery = document.getElementById("gallery");
    const productCount = document.getElementById("product-count");
    const selectedCount = document.getElementById("selected-count");
    let productCounter = 3; // התחל עם 3 מוצרים קיימים
    let selectedCounter = 0; // מספר המוצרים שנבחרו

    // עדכון ערך מונה המוצרים בגלריה
    productCount.textContent = productCounter;

    // פונקציה להוספת מוצר חדש
    addProductBtn.addEventListener("click", function () {
        productCounter++;
        const newProduct = document.createElement("div");
        newProduct.classList.add("product");
        newProduct.innerHTML = `
            <img src="https://via.placeholder.com/200" alt="מוצר ${productCounter}">
            <h3>מוצר ${productCounter}</h3>
            <p>Description</p>
            <p>Details about the product</p>
            <span class="stock">מלאי: ${Math.floor(Math.random() * 20) + 1} יחידות</span>
            <span class="price">₪${100 * productCounter}</span>
        `;
        newProduct.onclick = function () { selectProduct(); };
        gallery.appendChild(newProduct);
        productCount.textContent = productCounter;
    });

    // פונקציה לבחירת מוצר
    function selectProduct() {
        selectedCounter++;
        selectedCount.textContent = selectedCounter;
    }
   
    
    // הוספת אירוע onclick לכל מוצר קיים
    document.querySelectorAll(".product").forEach(product => {
        product.addEventListener("click", selectProduct);
    });
});
